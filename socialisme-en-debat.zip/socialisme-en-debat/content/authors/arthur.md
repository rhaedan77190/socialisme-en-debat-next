---
name: Arthur
bio: >
  Arthur est l’auteur principal de Socialisme en débat. Écrivain et collaborateur
  parlementaire, il analyse l’actualité politique avec une perspective
  matérialiste et révolutionnaire. Ses textes invitent à la réflexion et à
  l’action.
avatar: /images/post1.png
---